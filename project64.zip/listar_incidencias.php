<?php
include_once 'db.php';
include 'includes/header.php';

global $conn;
// Realiza la conexión a la base de datos (asegúrate de tener la conexión establecida)

// Realiza la consulta
$sql = "SELECT i.id, i.detalles, i.fecha, p.nombre as producto, u.nombre as usuario
        FROM incidencia i
        JOIN productos p ON i.control_pro = p.control_pro
        JOIN usuario u ON i.control_usu = u.control_usu
        ORDER BY i.fecha DESC";

$result = $conn->query($sql);
?>
<div class="container mt-5">
<h2>Listado de Incidencias</h2>

<?php
// Muestra los resultados en una tabla
if ($result->num_rows > 0) {
    echo '<table class="table table-striped">';
    echo '<tr><th>ID</th><th>Detalles</th><th>Fecha</th><th>Producto</th><th>Usuario</th></tr>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['detalles'] . '</td>';
        echo '<td>' . $row['fecha'] . '</td>';
        echo '<td>' . $row['producto'] . '</td>';
        echo '<td>' . $row['usuario'] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo 'No hay incidencias registradas.';
}
$conn->close();
?>
</div>

<?php
include 'includes/footer.php';
?>
