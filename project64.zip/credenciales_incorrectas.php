<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credenciales Inválidas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 50px;
        }

        h1 {
            color: #d9534f;
        }

        p {
            color: #777;
        }
    </style>
</head>
<body>
    <h1>Credenciales Inválidas</h1>
    <p>Las credenciales proporcionadas son inválidas. Verifica tu correo y contraseña e intenta nuevamente.</p>
</body>
</html>
